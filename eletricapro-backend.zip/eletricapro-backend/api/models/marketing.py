from sqlalchemy import Column, String, Integer, Text, DateTime, func
from sqlalchemy.dialects.postgresql import UUID, JSONB, ARRAY
import uuid
from core.database import Base


class MarketingPost(Base):
    __tablename__ = "marketing_posts"

    id         = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    week       = Column(Integer, default=1)
    day        = Column(String, default="")
    platform   = Column(String, nullable=False)
    title      = Column(String, nullable=False)
    format     = Column(String, default="")
    status     = Column(String, default="ideia")
    image_url  = Column(String, default="")
    notes      = Column(Text, default="")
    created_by = Column(String, default="")
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class MarketingIdea(Base):
    __tablename__ = "marketing_ideas"

    id         = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    text       = Column(String, nullable=False)
    platforms  = Column(JSONB, default=[])
    category   = Column(String, default="Geral")
    created_by = Column(String, default="")
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class MarketingBriefing(Base):
    __tablename__ = "marketing_briefings"

    id         = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    month      = Column(String, nullable=False)
    objective  = Column(String, default="")
    products   = Column(String, default="")
    promotions = Column(String, default="")
    tone       = Column(String, default="")
    platforms  = Column(JSONB, default=[])
    notes      = Column(Text, default="")
    created_by = Column(String, default="")
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class AgentSession(Base):
    __tablename__ = "agent_sessions"

    id           = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    briefing_id  = Column(UUID(as_uuid=True), nullable=True)
    messages     = Column(JSONB, default=[])
    active_agents= Column(JSONB, default=[])
    created_by   = Column(String, default="")
    created_at   = Column(DateTime(timezone=True), server_default=func.now())
    updated_at   = Column(DateTime(timezone=True), onupdate=func.now())
