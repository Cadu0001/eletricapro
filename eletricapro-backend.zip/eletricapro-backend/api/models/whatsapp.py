from sqlalchemy import Column, String, Integer, Boolean, DateTime, Text, func
from sqlalchemy.dialects.postgresql import UUID, JSONB
import uuid
from core.database import Base


class Contact(Base):
    __tablename__ = "contacts"

    id         = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name       = Column(String, nullable=False)
    phone      = Column(String, default="", index=True)
    avatar     = Column(String, default="👤")
    source     = Column(String, default="wa")       # wa | ig | fb
    status     = Column(String, default="open")     # open | prog | resolved
    unread     = Column(Integer, default=0)
    preview    = Column(String, default="")
    last_time  = Column(String, default="")
    extra      = Column(JSONB, default={})
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class Message(Base):
    __tablename__ = "messages"

    id          = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    contact_id  = Column(UUID(as_uuid=True), nullable=False, index=True)
    direction   = Column(String, default="in")      # in | out
    content     = Column(Text, nullable=False)
    msg_type    = Column(String, default="text")    # text | image | audio | doc
    wa_msg_id   = Column(String, default="")        # ID do WhatsApp
    read        = Column(Boolean, default=False)
    created_at  = Column(DateTime(timezone=True), server_default=func.now())
