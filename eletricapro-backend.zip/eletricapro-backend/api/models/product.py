from sqlalchemy import Column, String, Integer, Float, DateTime, func
from sqlalchemy.dialects.postgresql import UUID, JSONB
import uuid
from core.database import Base


class Product(Base):
    __tablename__ = "products"

    id         = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tiny_id    = Column(Integer, nullable=True, index=True)
    code       = Column(String, default="", index=True)
    name       = Column(String, nullable=False)
    price      = Column(Float, default=0)
    stock      = Column(Float, default=0)
    unit       = Column(String, default="un")
    category   = Column(String, default="")
    extra      = Column(JSONB, default={})
    synced_at  = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
