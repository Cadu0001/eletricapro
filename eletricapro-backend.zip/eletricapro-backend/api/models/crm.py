from sqlalchemy import Column, String, Integer, Float, Boolean, DateTime, Text, ForeignKey, func
from sqlalchemy.dialects.postgresql import UUID, JSONB
import uuid
from core.database import Base


class Opportunity(Base):
    __tablename__ = "opportunities"

    id         = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name       = Column(String, nullable=False)
    company    = Column(String, default="")
    value      = Column(Float, default=0)
    stage      = Column(String, default="lead")       # lead|quali|proposta|negoc|fechado|perdido
    channel    = Column(String, default="wa")          # wa|ml|tel|loja|ig|site
    score      = Column(String, default="medium")      # hot|warm|medium|cold
    owner      = Column(String, default="")
    product    = Column(String, default="")
    days       = Column(Integer, default=0)
    lost_reason= Column(String, default="")
    notes      = Column(Text, default="")
    extra      = Column(JSONB, default={})
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class Task(Base):
    __tablename__ = "tasks"

    id          = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    description = Column(String, nullable=False)
    due_date    = Column(String, default="")
    owner       = Column(String, default="")
    related_to  = Column(String, default="")
    done        = Column(Boolean, default=False)
    created_at  = Column(DateTime(timezone=True), server_default=func.now())
