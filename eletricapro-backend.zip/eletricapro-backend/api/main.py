"""
ElétricaPro — FastAPI Backend
Entry point principal
"""
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware

from core.config import settings
from core.database import init_db
from routers import auth, crm, whatsapp, marketplace, products, marketing, proxy, websocket


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup e shutdown da aplicação"""
    await init_db()
    print(f"✅ ElétricaPro API iniciada — {settings.environment.upper()}")
    yield
    print("🛑 ElétricaPro API encerrada")


app = FastAPI(
    title="ElétricaPro API",
    description="Backend do sistema comercial inteligente para distribuidoras elétricas",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/api/docs" if settings.environment == "development" else None,
    redoc_url=None,
)

# ── Middlewares ──
app.add_middleware(GZipMiddleware, minimum_size=1000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Routers ──
app.include_router(auth.router,        prefix="/api/auth",        tags=["Auth"])
app.include_router(crm.router,         prefix="/api/crm",         tags=["CRM"])
app.include_router(whatsapp.router,    prefix="/api/whatsapp",    tags=["WhatsApp"])
app.include_router(marketplace.router, prefix="/api/marketplace", tags=["Marketplace"])
app.include_router(products.router,    prefix="/api/products",    tags=["Produtos"])
app.include_router(marketing.router,   prefix="/api/marketing",   tags=["Marketing"])
app.include_router(proxy.router,       prefix="/api/proxy",       tags=["Proxy IA"])
app.include_router(websocket.router,   prefix="/api/ws",          tags=["WebSocket"])


@app.get("/api/health")
async def health():
    return {"status": "ok", "version": "1.0.0", "env": settings.environment}
