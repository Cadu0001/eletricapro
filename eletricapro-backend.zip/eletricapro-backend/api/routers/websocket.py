"""
WebSocket router — eventos em tempo real para o dashboard
"""
import asyncio, json
from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from typing import Set

router = APIRouter()

# Conjunto de conexões ativas
_connections: Set[WebSocket] = set()


@router.websocket("/live")
async def websocket_live(websocket: WebSocket):
    """
    Conexão WebSocket para o ticker ao vivo do dashboard.
    Frontend conecta em: wss://app.suaeletrica.com.br/api/ws/live
    """
    await websocket.accept()
    _connections.add(websocket)
    try:
        while True:
            # Aguarda mensagem do cliente (ping ou comando)
            data = await asyncio.wait_for(websocket.receive_text(), timeout=30)
            msg = json.loads(data) if data else {}

            if msg.get("type") == "ping":
                await websocket.send_json({"type": "pong"})

    except (WebSocketDisconnect, asyncio.TimeoutError):
        pass
    finally:
        _connections.discard(websocket)


async def broadcast(event_type: str, payload: dict):
    """
    Envia evento para todos os clientes conectados.
    Chamar de qualquer lugar: await broadcast("new_lead", {...})
    """
    if not _connections:
        return
    msg = json.dumps({"type": event_type, "data": payload})
    dead = set()
    for ws in _connections:
        try:
            await ws.send_text(msg)
        except Exception:
            dead.add(ws)
    _connections.difference_update(dead)
