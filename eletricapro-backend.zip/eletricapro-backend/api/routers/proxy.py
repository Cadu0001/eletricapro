"""
Proxy router — chaves de API ficam APENAS no servidor
Frontend chama /api/proxy/* e nunca vê as keys reais
"""
import httpx
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Any, Optional, List

from core.config import settings
from core.security import get_current_user

router = APIRouter()


# ── Schemas ──
class ClaudeRequest(BaseModel):
    messages: List[dict]
    system: Optional[str] = None
    max_tokens: int = 1000
    model: str = "claude-sonnet-4-20250514"


class GeminiImageRequest(BaseModel):
    prompt: str
    aspect_ratio: str = "1:1"


class ElevenLabsRequest(BaseModel):
    text: str
    voice_id: str = "pNInz6obpgDQGcFmaJgB"


class TinyRequest(BaseModel):
    path: str
    body: dict = {}


# ── Claude / Anthropic ──
@router.post("/claude")
async def proxy_claude(
    req: ClaudeRequest,
    current_user: dict = Depends(get_current_user)
):
    if not settings.anthropic_api_key:
        raise HTTPException(503, "Claude API não configurada no servidor")

    async with httpx.AsyncClient(timeout=60) as client:
        res = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": settings.anthropic_api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": req.model,
                "max_tokens": req.max_tokens,
                "system": req.system,
                "messages": req.messages,
            }
        )
    if not res.is_success:
        raise HTTPException(res.status_code, res.text)
    return res.json()


# ── Gemini / Nano Banana 2 ──
@router.post("/gemini/image")
async def proxy_gemini_image(
    req: GeminiImageRequest,
    current_user: dict = Depends(get_current_user)
):
    if not settings.gemini_api_key:
        raise HTTPException(503, "Gemini API não configurada no servidor")

    async with httpx.AsyncClient(timeout=120) as client:
        res = await client.post(
            f"https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-image-preview:generateContent?key={settings.gemini_api_key}",
            json={
                "contents": [{"parts": [{"text": req.prompt}]}],
                "generationConfig": {
                    "responseModalities": ["IMAGE", "TEXT"],
                    "aspectRatio": req.aspect_ratio,
                }
            }
        )
    if not res.is_success:
        raise HTTPException(res.status_code, res.text)
    return res.json()


# ── ElevenLabs ──
@router.post("/elevenlabs/tts")
async def proxy_elevenlabs(
    req: ElevenLabsRequest,
    current_user: dict = Depends(get_current_user)
):
    if not settings.elevenlabs_api_key:
        raise HTTPException(503, "ElevenLabs não configurada no servidor")

    async with httpx.AsyncClient(timeout=60) as client:
        res = await client.post(
            f"https://api.elevenlabs.io/v1/text-to-speech/{req.voice_id}",
            headers={
                "xi-api-key": settings.elevenlabs_api_key,
                "content-type": "application/json",
            },
            json={
                "text": req.text,
                "model_id": "eleven_multilingual_v2",
                "voice_settings": {
                    "stability": 0.5,
                    "similarity_boost": 0.75,
                    "style": 0.3,
                    "use_speaker_boost": True,
                }
            }
        )
    if not res.is_success:
        raise HTTPException(res.status_code, res.text)

    from fastapi.responses import Response
    return Response(content=res.content, media_type="audio/mpeg")


# ── Tiny ERP ──
@router.post("/tiny")
async def proxy_tiny(
    req: TinyRequest,
    current_user: dict = Depends(get_current_user)
):
    if not settings.tiny_api_token:
        raise HTTPException(503, "Tiny ERP não configurado no servidor")

    async with httpx.AsyncClient(timeout=30) as client:
        res = await client.post(
            f"{settings.tiny_api_url}{req.path}.php",
            data={
                "token": settings.tiny_api_token,
                "formato": "json",
                **{k: str(v) for k, v in req.body.items()},
            }
        )
    if not res.is_success:
        raise HTTPException(res.status_code, res.text)
    return res.json()


# ── Status das integrações ──
@router.get("/status")
async def integration_status(current_user: dict = Depends(get_current_user)):
    """Verifica quais APIs estão configuradas (sem expor as keys)"""
    return {
        "claude":      bool(settings.anthropic_api_key),
        "gemini":      bool(settings.gemini_api_key),
        "elevenlabs":  bool(settings.elevenlabs_api_key),
        "openai":      bool(settings.openai_api_key),
        "tiny":        bool(settings.tiny_api_token),
        "whatsapp":    bool(settings.wa_token),
    }
