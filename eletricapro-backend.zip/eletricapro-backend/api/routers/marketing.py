"""
Marketing router — calendário editorial, banco de ideias, briefings, sessões de agentes
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from typing import Optional, List
from uuid import UUID

from core.database import get_db
from core.security import get_current_user, require_manager
from models.marketing import MarketingPost, MarketingIdea, MarketingBriefing, AgentSession

router = APIRouter()


# ── Posts (Calendário) ──
class PostCreate(BaseModel):
    week: int = 1
    day: str = "A definir"
    platform: str
    title: str
    format: str = ""
    status: str = "ideia"
    notes: str = ""


class PostUpdate(BaseModel):
    status: Optional[str] = None
    title: Optional[str] = None
    day: Optional[str] = None
    format: Optional[str] = None
    image_url: Optional[str] = None
    notes: Optional[str] = None


@router.get("/posts")
async def list_posts(
    week: Optional[int] = None,
    status: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    q = select(MarketingPost).order_by(MarketingPost.week, MarketingPost.created_at)
    if week:
        q = q.where(MarketingPost.week == week)
    if status:
        q = q.where(MarketingPost.status == status)
    result = await db.execute(q)
    posts = result.scalars().all()
    return [_post_dict(p) for p in posts]


@router.post("/posts")
async def create_post(
    data: PostCreate,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    post = MarketingPost(**data.model_dump(), created_by=current_user.get("name", ""))
    db.add(post)
    await db.commit()
    await db.refresh(post)
    return {"id": str(post.id), "message": "Post criado"}


@router.patch("/posts/{post_id}")
async def update_post(
    post_id: UUID,
    data: PostUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    result = await db.execute(select(MarketingPost).where(MarketingPost.id == post_id))
    post = result.scalar_one_or_none()
    if not post:
        raise HTTPException(404, "Post não encontrado")
    for k, v in data.model_dump(exclude_none=True).items():
        setattr(post, k, v)
    await db.commit()
    return {"message": "Atualizado"}


@router.delete("/posts/{post_id}")
async def delete_post(
    post_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    result = await db.execute(select(MarketingPost).where(MarketingPost.id == post_id))
    post = result.scalar_one_or_none()
    if not post:
        raise HTTPException(404, "Post não encontrado")
    await db.delete(post)
    await db.commit()
    return {"message": "Removido"}


# ── Ideas ──
class IdeaCreate(BaseModel):
    text: str
    platforms: List[str] = []
    category: str = "Geral"


@router.get("/ideas")
async def list_ideas(
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    result = await db.execute(select(MarketingIdea).order_by(MarketingIdea.created_at.desc()))
    ideas = result.scalars().all()
    return [{"id": str(i.id), "text": i.text, "platforms": i.platforms,
             "category": i.category} for i in ideas]


@router.post("/ideas")
async def create_idea(
    data: IdeaCreate,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    idea = MarketingIdea(**data.model_dump(), created_by=current_user.get("name", ""))
    db.add(idea)
    await db.commit()
    await db.refresh(idea)
    return {"id": str(idea.id), "message": "Ideia adicionada"}


@router.delete("/ideas/{idea_id}")
async def delete_idea(
    idea_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    result = await db.execute(select(MarketingIdea).where(MarketingIdea.id == idea_id))
    idea = result.scalar_one_or_none()
    if not idea:
        raise HTTPException(404, "Ideia não encontrada")
    await db.delete(idea)
    await db.commit()
    return {"message": "Removida"}


# ── Briefings ──
class BriefingCreate(BaseModel):
    month: str
    objective: str = ""
    products: str = ""
    promotions: str = ""
    tone: str = ""
    platforms: List[str] = []
    notes: str = ""


@router.get("/briefings/latest")
async def get_latest_briefing(
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    result = await db.execute(
        select(MarketingBriefing).order_by(MarketingBriefing.created_at.desc()).limit(1)
    )
    b = result.scalar_one_or_none()
    if not b:
        return {}
    return {"id": str(b.id), "month": b.month, "objective": b.objective,
            "products": b.products, "promotions": b.promotions,
            "tone": b.tone, "platforms": b.platforms, "notes": b.notes}


@router.post("/briefings")
async def create_briefing(
    data: BriefingCreate,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(require_manager),
):
    b = MarketingBriefing(**data.model_dump(), created_by=current_user.get("name", ""))
    db.add(b)
    await db.commit()
    await db.refresh(b)
    return {"id": str(b.id), "message": "Briefing salvo"}


# ── Agent Sessions ──
class SessionUpdate(BaseModel):
    messages: List[dict]
    active_agents: List[str] = []


@router.get("/sessions/latest")
async def get_latest_session(
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    result = await db.execute(
        select(AgentSession).order_by(AgentSession.updated_at.desc()).limit(1)
    )
    s = result.scalar_one_or_none()
    if not s:
        return {"messages": [], "active_agents": []}
    return {"id": str(s.id), "messages": s.messages, "active_agents": s.active_agents}


@router.post("/sessions")
async def upsert_session(
    data: SessionUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    # Pega a sessão mais recente do usuário ou cria uma nova
    result = await db.execute(
        select(AgentSession)
        .where(AgentSession.created_by == current_user.get("name", ""))
        .order_by(AgentSession.created_at.desc())
        .limit(1)
    )
    session = result.scalar_one_or_none()
    if session:
        session.messages = data.messages
        session.active_agents = data.active_agents
    else:
        session = AgentSession(
            messages=data.messages,
            active_agents=data.active_agents,
            created_by=current_user.get("name", ""),
        )
        db.add(session)
    await db.commit()
    return {"message": "Sessão salva"}


def _post_dict(p: MarketingPost) -> dict:
    return {
        "id": str(p.id), "week": p.week, "day": p.day,
        "platform": p.platform, "title": p.title, "format": p.format,
        "status": p.status, "image_url": p.image_url, "notes": p.notes,
    }
