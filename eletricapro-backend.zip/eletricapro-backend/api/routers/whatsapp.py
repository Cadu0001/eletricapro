"""
WhatsApp router — webhook Meta + envio de mensagens
"""
import hashlib, hmac, json
import httpx
from fastapi import APIRouter, Request, Response, Depends, HTTPException, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from uuid import UUID

from core.config import settings
from core.database import get_db
from core.security import get_current_user
from models.whatsapp import Contact, Message

router = APIRouter()

WA_BASE = "https://graph.facebook.com/v21.0"


# ── Webhook verification (GET) ──
@router.get("/webhook")
async def verify_webhook(
    hub_mode: str = None,
    hub_challenge: str = None,
    hub_verify_token: str = None,
):
    if hub_mode == "subscribe" and hub_verify_token == settings.wa_webhook_verify_token:
        return Response(content=hub_challenge, media_type="text/plain")
    raise HTTPException(403, "Token de verificação inválido")


# ── Webhook events (POST) ──
@router.post("/webhook")
async def receive_webhook(
    request: Request,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
):
    body = await request.body()

    # Verificar assinatura Meta (opcional mas recomendado)
    # signature = request.headers.get("x-hub-signature-256", "")
    # _verify_signature(body, signature)

    payload = json.loads(body)
    background_tasks.add_task(_process_webhook, payload, db)
    return {"status": "ok"}


async def _process_webhook(payload: dict, db: AsyncSession):
    """Processa mensagens recebidas do WhatsApp"""
    try:
        for entry in payload.get("entry", []):
            for change in entry.get("changes", []):
                value = change.get("value", {})
                messages = value.get("messages", [])
                contacts_meta = value.get("contacts", [])

                for msg in messages:
                    phone = msg.get("from", "")
                    wa_msg_id = msg.get("id", "")
                    msg_type = msg.get("type", "text")
                    content = ""

                    if msg_type == "text":
                        content = msg.get("text", {}).get("body", "")
                    elif msg_type == "image":
                        content = "[Imagem recebida]"
                    elif msg_type == "audio":
                        content = "[Áudio recebido]"
                    elif msg_type == "document":
                        content = "[Documento recebido]"

                    # Nome do contato via metadata
                    contact_name = phone
                    for c in contacts_meta:
                        if c.get("wa_id") == phone:
                            contact_name = c.get("profile", {}).get("name", phone)

                    # Upsert contato
                    result = await db.execute(select(Contact).where(Contact.phone == phone))
                    contact = result.scalar_one_or_none()
                    if not contact:
                        contact = Contact(name=contact_name, phone=phone, source="wa")
                        db.add(contact)
                        await db.flush()

                    contact.unread = (contact.unread or 0) + 1
                    contact.preview = content[:80]

                    # Salvar mensagem
                    message = Message(
                        contact_id=contact.id,
                        direction="in",
                        content=content,
                        msg_type=msg_type,
                        wa_msg_id=wa_msg_id,
                    )
                    db.add(message)

                await db.commit()
    except Exception as e:
        print(f"❌ Webhook processing error: {e}")
        await db.rollback()


# ── Enviar mensagem ──
class SendMessageRequest(BaseModel):
    phone: str
    message: str
    contact_id: UUID = None


@router.post("/send")
async def send_message(
    data: SendMessageRequest,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    if not settings.wa_token:
        raise HTTPException(503, "WhatsApp API não configurada")

    async with httpx.AsyncClient(timeout=30) as client:
        res = await client.post(
            f"{WA_BASE}/{settings.wa_phone_number_id}/messages",
            headers={
                "Authorization": f"Bearer {settings.wa_token}",
                "Content-Type": "application/json",
            },
            json={
                "messaging_product": "whatsapp",
                "to": data.phone.replace("+", "").replace(" ", ""),
                "type": "text",
                "text": {"body": data.message},
            }
        )

    if not res.is_success:
        raise HTTPException(res.status_code, f"WhatsApp API error: {res.text}")

    wa_response = res.json()
    wa_msg_id = wa_response.get("messages", [{}])[0].get("id", "")

    # Salvar mensagem enviada no banco
    if data.contact_id:
        msg = Message(
            contact_id=data.contact_id,
            direction="out",
            content=data.message,
            msg_type="text",
            wa_msg_id=wa_msg_id,
            read=True,
        )
        db.add(msg)
        await db.commit()

    return {"message_id": wa_msg_id, "status": "sent"}


# ── Listar contatos / conversas ──
@router.get("/contacts")
async def list_contacts(
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    result = await db.execute(select(Contact).order_by(Contact.updated_at.desc()))
    contacts = result.scalars().all()
    return [{"id": str(c.id), "name": c.name, "phone": c.phone,
             "avatar": c.avatar, "status": c.status, "unread": c.unread,
             "preview": c.preview, "source": c.source} for c in contacts]


@router.get("/messages/{contact_id}")
async def get_messages(
    contact_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    result = await db.execute(
        select(Message)
        .where(Message.contact_id == contact_id)
        .order_by(Message.created_at.asc())
    )
    msgs = result.scalars().all()
    return [{"id": str(m.id), "direction": m.direction, "content": m.content,
             "type": m.msg_type, "read": m.read,
             "created_at": m.created_at.isoformat() if m.created_at else None}
            for m in msgs]
