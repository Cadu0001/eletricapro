"""
Marketplace router — Mercado Livre, Shopee, Amazon (stub inicial)
"""
from fastapi import APIRouter, Depends
from core.security import get_current_user

router = APIRouter()


@router.get("/questions")
async def list_questions(current_user: dict = Depends(get_current_user)):
    """Perguntas pendentes de todos os marketplaces"""
    # TODO: integrar ML API, Shopee API, Amazon SP-API
    return {"questions": [], "message": "Integração marketplace em desenvolvimento"}


@router.get("/status")
async def marketplace_status(current_user: dict = Depends(get_current_user)):
    return {
        "mercado_livre": {"connected": False, "pending_questions": 0},
        "shopee":        {"connected": False, "pending_questions": 0},
        "amazon":        {"connected": False, "pending_questions": 0},
    }
