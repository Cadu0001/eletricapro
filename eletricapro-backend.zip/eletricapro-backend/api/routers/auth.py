"""
Auth router — Google OAuth2 (Workspace) + JWT
"""
import httpx
from fastapi import APIRouter, HTTPException, Depends
from fastapi.responses import RedirectResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from core.config import settings
from core.database import get_db
from core.security import create_access_token, get_current_user
from models.user import User

router = APIRouter()

GOOGLE_AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"
GOOGLE_USERINFO_URL = "https://www.googleapis.com/oauth2/v3/userinfo"


@router.get("/google")
async def google_login():
    """Redireciona para o Google OAuth"""
    params = {
        "client_id": settings.google_client_id,
        "redirect_uri": settings.google_redirect_uri,
        "response_type": "code",
        "scope": "openid email profile",
        "hd": settings.allowed_google_domain,  # restringe ao domínio Workspace
        "access_type": "offline",
        "prompt": "select_account",
    }
    url = GOOGLE_AUTH_URL + "?" + "&".join(f"{k}={v}" for k, v in params.items())
    return RedirectResponse(url)


@router.get("/google/callback")
async def google_callback(code: str, db: AsyncSession = Depends(get_db)):
    """Callback do Google — troca code por token e cria sessão"""

    # 1. Trocar code por access_token
    async with httpx.AsyncClient() as client:
        token_res = await client.post(GOOGLE_TOKEN_URL, data={
            "code": code,
            "client_id": settings.google_client_id,
            "client_secret": settings.google_client_secret,
            "redirect_uri": settings.google_redirect_uri,
            "grant_type": "authorization_code",
        })
        token_data = token_res.json()
        if "error" in token_data:
            raise HTTPException(400, f"Erro OAuth: {token_data['error']}")

        # 2. Buscar dados do usuário
        user_res = await client.get(
            GOOGLE_USERINFO_URL,
            headers={"Authorization": f"Bearer {token_data['access_token']}"}
        )
        google_user = user_res.json()

    email = google_user.get("email", "")
    domain = email.split("@")[-1] if "@" in email else ""

    # 3. Validar domínio Workspace
    if settings.allowed_google_domain and domain != settings.allowed_google_domain:
        raise HTTPException(403, f"Acesso restrito ao domínio {settings.allowed_google_domain}")

    # 4. Buscar ou criar usuário no banco
    result = await db.execute(select(User).where(User.email == email))
    user = result.scalar_one_or_none()

    if not user:
        # Primeiro acesso: cria usuário com perfil padrão vendedor
        user = User(
            email=email,
            name=google_user.get("name", email),
            avatar_url=google_user.get("picture", ""),
            google_id=google_user.get("sub", ""),
            role="vendedor",
            active=True,
        )
        db.add(user)
        await db.commit()
        await db.refresh(user)

    if not user.active:
        raise HTTPException(403, "Usuário desativado. Contate o administrador.")

    # 5. Gerar JWT
    token = create_access_token({
        "sub": str(user.id),
        "email": user.email,
        "name": user.name,
        "avatar": user.avatar_url,
        "role": user.role,
    })

    # 6. Redirecionar para o frontend com token
    frontend_url = f"https://{settings.domain}/#token={token}"
    return RedirectResponse(frontend_url)


@router.get("/me")
async def get_me(current_user: dict = Depends(get_current_user)):
    """Retorna dados do usuário logado"""
    return current_user


@router.post("/logout")
async def logout():
    """Logout — frontend deve descartar o token"""
    return {"message": "Logout realizado"}
