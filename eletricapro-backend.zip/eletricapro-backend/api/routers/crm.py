from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from pydantic import BaseModel
from typing import Optional, List
from uuid import UUID

from core.database import get_db
from core.security import get_current_user
from models.crm import Opportunity, Task

router = APIRouter()


# ── Schemas ──
class OpportunityCreate(BaseModel):
    name: str
    company: str = ""
    value: float = 0
    stage: str = "lead"
    channel: str = "wa"
    score: str = "medium"
    owner: str = ""
    product: str = ""
    notes: str = ""


class OpportunityUpdate(BaseModel):
    name: Optional[str] = None
    company: Optional[str] = None
    value: Optional[float] = None
    stage: Optional[str] = None
    score: Optional[str] = None
    owner: Optional[str] = None
    product: Optional[str] = None
    notes: Optional[str] = None
    lost_reason: Optional[str] = None


class TaskCreate(BaseModel):
    description: str
    due_date: str = ""
    owner: str = ""
    related_to: str = ""


# ── Opportunities ──
@router.get("/opportunities")
async def list_opportunities(
    stage: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    q = select(Opportunity).order_by(Opportunity.created_at.desc())
    if stage:
        q = q.where(Opportunity.stage == stage)
    result = await db.execute(q)
    opps = result.scalars().all()
    return [{"id": str(o.id), "name": o.name, "company": o.company,
             "value": o.value, "stage": o.stage, "channel": o.channel,
             "score": o.score, "owner": o.owner, "product": o.product,
             "days": o.days, "notes": o.notes} for o in opps]


@router.post("/opportunities")
async def create_opportunity(
    data: OpportunityCreate,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    opp = Opportunity(**data.model_dump(), owner=data.owner or current_user.get("name", ""))
    db.add(opp)
    await db.commit()
    await db.refresh(opp)
    return {"id": str(opp.id), "message": "Oportunidade criada"}


@router.patch("/opportunities/{opp_id}")
async def update_opportunity(
    opp_id: UUID,
    data: OpportunityUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    result = await db.execute(select(Opportunity).where(Opportunity.id == opp_id))
    opp = result.scalar_one_or_none()
    if not opp:
        raise HTTPException(404, "Oportunidade não encontrada")
    for k, v in data.model_dump(exclude_none=True).items():
        setattr(opp, k, v)
    await db.commit()
    return {"message": "Atualizado"}


@router.delete("/opportunities/{opp_id}")
async def delete_opportunity(
    opp_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    result = await db.execute(select(Opportunity).where(Opportunity.id == opp_id))
    opp = result.scalar_one_or_none()
    if not opp:
        raise HTTPException(404, "Oportunidade não encontrada")
    await db.delete(opp)
    await db.commit()
    return {"message": "Removido"}


# ── Tasks ──
@router.get("/tasks")
async def list_tasks(
    done: Optional[bool] = None,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    q = select(Task).order_by(Task.created_at.desc())
    if done is not None:
        q = q.where(Task.done == done)
    result = await db.execute(q)
    tasks = result.scalars().all()
    return [{"id": str(t.id), "description": t.description, "due_date": t.due_date,
             "owner": t.owner, "related_to": t.related_to, "done": t.done} for t in tasks]


@router.post("/tasks")
async def create_task(
    data: TaskCreate,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    task = Task(**data.model_dump())
    db.add(task)
    await db.commit()
    await db.refresh(task)
    return {"id": str(task.id), "message": "Tarefa criada"}


@router.patch("/tasks/{task_id}/done")
async def complete_task(
    task_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    result = await db.execute(select(Task).where(Task.id == task_id))
    task = result.scalar_one_or_none()
    if not task:
        raise HTTPException(404, "Tarefa não encontrada")
    task.done = not task.done
    await db.commit()
    return {"done": task.done}


# ── Dashboard stats ──
@router.get("/stats")
async def crm_stats(
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    total = await db.execute(func.count(Opportunity.id))
    by_stage = await db.execute(
        select(Opportunity.stage, func.count(Opportunity.id), func.sum(Opportunity.value))
        .group_by(Opportunity.stage)
    )
    return {
        "total": total.scalar(),
        "by_stage": [{"stage": r[0], "count": r[1], "value": float(r[2] or 0)}
                     for r in by_stage.all()]
    }
