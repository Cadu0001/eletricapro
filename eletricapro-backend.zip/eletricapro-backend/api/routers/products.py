"""
Products router — CRUD + sincronização com Tiny ERP
"""
import httpx
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, or_
from pydantic import BaseModel
from typing import Optional
from uuid import UUID

from core.config import settings
from core.database import get_db
from core.security import get_current_user, require_manager
from models.product import Product

router = APIRouter()


class ProductCreate(BaseModel):
    code: str = ""
    name: str
    price: float = 0
    stock: float = 0
    unit: str = "un"
    category: str = ""


class ProductUpdate(BaseModel):
    name: Optional[str] = None
    price: Optional[float] = None
    stock: Optional[float] = None
    unit: Optional[str] = None
    category: Optional[str] = None


# ── List / Search ──
@router.get("/")
async def list_products(
    q: Optional[str] = None,
    category: Optional[str] = None,
    low_stock: Optional[bool] = None,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    query = select(Product).order_by(Product.name)
    if q:
        query = query.where(or_(
            Product.name.ilike(f"%{q}%"),
            Product.code.ilike(f"%{q}%"),
        ))
    if category:
        query = query.where(Product.category == category)
    if low_stock:
        query = query.where(Product.stock <= 10)

    result = await db.execute(query)
    products = result.scalars().all()
    return [_to_dict(p) for p in products]


@router.get("/{product_id}")
async def get_product(
    product_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    result = await db.execute(select(Product).where(Product.id == product_id))
    p = result.scalar_one_or_none()
    if not p:
        raise HTTPException(404, "Produto não encontrado")
    return _to_dict(p)


@router.post("/")
async def create_product(
    data: ProductCreate,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(require_manager),
):
    p = Product(**data.model_dump())
    db.add(p)
    await db.commit()
    await db.refresh(p)
    return {"id": str(p.id), "message": "Produto criado"}


@router.patch("/{product_id}")
async def update_product(
    product_id: UUID,
    data: ProductUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(require_manager),
):
    result = await db.execute(select(Product).where(Product.id == product_id))
    p = result.scalar_one_or_none()
    if not p:
        raise HTTPException(404, "Produto não encontrado")
    for k, v in data.model_dump(exclude_none=True).items():
        setattr(p, k, v)
    await db.commit()
    return {"message": "Atualizado"}


# ── Tiny ERP Sync ──
@router.post("/sync/tiny")
async def sync_from_tiny(
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(require_manager),
):
    """Dispara sincronização em background — retorna imediatamente"""
    background_tasks.add_task(_sync_tiny_products, db)
    return {"message": "Sincronização iniciada em background"}


async def _sync_tiny_products(db: AsyncSession):
    """Busca produtos do Tiny e upsert no PostgreSQL"""
    if not settings.tiny_api_token:
        return

    try:
        async with httpx.AsyncClient(timeout=30) as client:
            res = await client.post(
                f"{settings.tiny_api_url}/produtos.pesquisa.php",
                data={"token": settings.tiny_api_token, "formato": "json"}
            )
            data = res.json()

        produtos = data.get("retorno", {}).get("produtos", [])
        for item in produtos:
            p = item.get("produto", {})
            tiny_id = int(p.get("id", 0))
            if not tiny_id:
                continue

            # Upsert
            result = await db.execute(select(Product).where(Product.tiny_id == tiny_id))
            existing = result.scalar_one_or_none()

            if existing:
                existing.name  = p.get("descricao", existing.name)
                existing.price = float(p.get("preco", existing.price) or 0)
                existing.stock = float(p.get("estoque", existing.stock) or 0)
                existing.unit  = p.get("unidade", existing.unit) or "un"
            else:
                new_p = Product(
                    tiny_id  = tiny_id,
                    code     = p.get("codigo", ""),
                    name     = p.get("descricao", ""),
                    price    = float(p.get("preco", 0) or 0),
                    stock    = float(p.get("estoque", 0) or 0),
                    unit     = p.get("unidade", "un") or "un",
                )
                db.add(new_p)

        await db.commit()
        print(f"✅ Tiny sync: {len(produtos)} produtos atualizados")

    except Exception as e:
        print(f"❌ Tiny sync error: {e}")
        await db.rollback()


def _to_dict(p: Product) -> dict:
    return {
        "id": str(p.id),
        "tiny_id": p.tiny_id,
        "code": p.code,
        "name": p.name,
        "price": p.price,
        "stock": p.stock,
        "unit": p.unit,
        "category": p.category,
    }
