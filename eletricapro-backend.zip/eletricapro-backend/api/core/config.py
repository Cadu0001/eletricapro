from pydantic_settings import BaseSettings
from typing import List


class Settings(BaseSettings):
    # Servidor
    domain: str = "localhost"
    environment: str = "development"
    secret_key: str = "dev-secret-change-in-prod"
    allowed_origins: List[str] = ["http://localhost:3000", "http://localhost:8000"]

    # Banco
    database_url: str = "postgresql+asyncpg://ep_user:password@localhost:5432/eletricapro"

    # Redis
    redis_url: str = "redis://localhost:6379/0"

    # Google OAuth
    google_client_id: str = ""
    google_client_secret: str = ""
    google_redirect_uri: str = ""
    allowed_google_domain: str = ""

    # IAs
    anthropic_api_key: str = ""
    gemini_api_key: str = ""
    elevenlabs_api_key: str = ""
    openai_api_key: str = ""

    # Tiny ERP
    tiny_api_token: str = ""
    tiny_api_url: str = "https://api.tiny.com.br/api2"

    # WhatsApp
    wa_token: str = ""
    wa_phone_number_id: str = ""
    wa_webhook_verify_token: str = ""

    class Config:
        env_file = ".env"
        case_sensitive = False


settings = Settings()
