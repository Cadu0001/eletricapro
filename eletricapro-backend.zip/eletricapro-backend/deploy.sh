#!/bin/bash
# ═══════════════════════════════════════════════════════════
# ElétricaPro — Script de Deploy
# Uso: ./deploy.sh [first|update|logs|status|down]
# ═══════════════════════════════════════════════════════════

set -e
DOMAIN="app.suaeletrica.com.br"
COMPOSE="docker compose"

case "${1:-update}" in

  # ── Primeiro deploy no VPS ──
  first)
    echo "🚀 Primeiro deploy — ElétricaPro"

    # 1. Verificar .env
    if [ ! -f .env ]; then
      cp .env.example .env
      echo "⚠️  .env criado a partir do .env.example"
      echo "    Preencha as variáveis antes de continuar!"
      exit 1
    fi

    # 2. Copiar frontend
    mkdir -p frontend
    cp ../frontend/eletricapro_v2.html frontend/index.html
    echo "✅ Frontend copiado"

    # 3. Criar diretório SSL
    mkdir -p nginx/ssl

    # 4. Build e start sem SSL (para gerar certificado)
    $COMPOSE up -d nginx postgres redis
    sleep 5

    # 5. Gerar certificado Let's Encrypt
    docker run --rm \
      -v "$(pwd)/nginx/ssl:/etc/letsencrypt" \
      -v "$(pwd)/nginx/certbot_webroot:/var/www/certbot" \
      certbot/certbot certonly \
      --webroot -w /var/www/certbot \
      -d $DOMAIN \
      --email admin@$DOMAIN \
      --agree-tos --non-interactive
    echo "✅ SSL gerado"

    # 6. Start completo
    $COMPOSE up -d --build
    echo "✅ Todos os serviços rodando"
    $COMPOSE ps
    ;;

  # ── Atualizar código ──
  update)
    echo "🔄 Atualizando ElétricaPro..."

    # Atualiza frontend
    if [ -f "../frontend/eletricapro_v2.html" ]; then
      cp ../frontend/eletricapro_v2.html frontend/index.html
      echo "✅ Frontend atualizado"
    fi

    # Rebuild API sem downtime
    $COMPOSE build api
    $COMPOSE up -d --no-deps api
    echo "✅ API atualizada"
    $COMPOSE ps
    ;;

  # ── Logs ──
  logs)
    SERVICE=${2:-api}
    $COMPOSE logs -f --tail=100 $SERVICE
    ;;

  # ── Status ──
  status)
    $COMPOSE ps
    echo ""
    echo "📊 Uso de recursos:"
    docker stats --no-stream --format "table {{.Name}}\t{{.CPUPerc}}\t{{.MemUsage}}"
    ;;

  # ── Parar tudo ──
  down)
    $COMPOSE down
    echo "🛑 Todos os serviços parados"
    ;;

  # ── Backup do banco ──
  backup)
    TIMESTAMP=$(date +%Y%m%d_%H%M%S)
    docker exec ep_postgres pg_dump -U ep_user eletricapro > "backup_$TIMESTAMP.sql"
    echo "✅ Backup salvo: backup_$TIMESTAMP.sql"
    ;;

  *)
    echo "Uso: ./deploy.sh [first|update|logs [service]|status|down|backup]"
    ;;
esac
