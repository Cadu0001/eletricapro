-- ElétricaPro — PostgreSQL init
-- Roda automaticamente na primeira inicialização do container

-- Extensão UUID
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Índices adicionais após criação das tabelas pelo SQLAlchemy
-- (O SQLAlchemy cria as tabelas; aqui ficam apenas otimizações extras)

-- A seguir, dados iniciais de exemplo (remova em produção se quiser começar vazio)

-- Usuário admin padrão (senha via Google OAuth — não tem senha local)
-- INSERT INTO users (id, email, name, role, active)
-- VALUES (uuid_generate_v4(), 'admin@suaeletrica.com.br', 'Carlos Admin', 'admin', true)
-- ON CONFLICT (email) DO NOTHING;

-- Nota: as tabelas são criadas automaticamente pelo init_db() do SQLAlchemy
-- Este arquivo serve apenas para configurações extras e dados de seed
