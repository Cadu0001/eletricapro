# ElétricaPro — Backend

Stack: **FastAPI + PostgreSQL + Redis + Nginx + Docker**  
VPS: Hostinger KVM 1 (1 vCPU / 4GB RAM)

---

## Estrutura

```
eletricapro-backend/
├── docker-compose.yml       ← orquestra tudo
├── .env.example             ← copie para .env e preencha
├── deploy.sh                ← script de deploy
│
├── api/                     ← FastAPI
│   ├── main.py              ← entry point
│   ├── requirements.txt
│   ├── Dockerfile
│   ├── core/
│   │   ├── config.py        ← lê variáveis do .env
│   │   ├── database.py      ← SQLAlchemy async
│   │   └── security.py      ← JWT + roles
│   ├── models/              ← tabelas PostgreSQL
│   │   ├── user.py
│   │   ├── crm.py
│   │   ├── product.py
│   │   ├── whatsapp.py
│   │   └── marketing.py
│   └── routers/             ← endpoints REST
│       ├── auth.py          ← Google OAuth2 + JWT
│       ├── crm.py           ← oportunidades + tarefas
│       ├── products.py      ← catálogo + sync Tiny
│       ├── whatsapp.py      ← webhook + envio
│       ├── marketing.py     ← calendário + agentes
│       ├── marketplace.py   ← ML/Shopee/Amazon (stub)
│       ├── proxy.py         ← proxy seguro para IAs
│       └── websocket.py     ← eventos em tempo real
│
├── nginx/
│   └── nginx.conf           ← reverse proxy + SSL
│
├── postgres/
│   └── init.sql             ← configuração inicial
│
└── frontend/
    └── index.html           ← eletricapro_v2.html (copiado pelo deploy.sh)
```

---

## Primeiro deploy no VPS

```bash
# 1. Clonar no VPS
git clone https://github.com/sua-org/eletricapro-backend.git
cd eletricapro-backend

# 2. Configurar variáveis
cp .env.example .env
nano .env   # preencher domain, senhas, API keys

# 3. Tornar deploy.sh executável
chmod +x deploy.sh

# 4. Primeiro deploy (gera SSL + sobe tudo)
./deploy.sh first
```

## Atualizar

```bash
git pull
./deploy.sh update
```

## Comandos úteis

```bash
./deploy.sh status          # ver status de todos os serviços
./deploy.sh logs api        # logs da API em tempo real
./deploy.sh logs nginx      # logs do Nginx
./deploy.sh backup          # backup do banco de dados
./deploy.sh down            # parar tudo
```

---

## Rotas da API

| Método | Rota | Descrição |
|--------|------|-----------|
| GET | /api/health | Status da API |
| GET | /api/auth/google | Login Google |
| GET | /api/auth/me | Usuário logado |
| GET | /api/crm/opportunities | Listar oportunidades |
| POST | /api/crm/opportunities | Criar oportunidade |
| PATCH | /api/crm/opportunities/{id} | Atualizar |
| GET | /api/products/ | Listar produtos |
| POST | /api/products/sync/tiny | Sync com Tiny ERP |
| GET | /api/whatsapp/contacts | Listar contatos |
| POST | /api/whatsapp/send | Enviar mensagem |
| POST | /api/whatsapp/webhook | Receber mensagens (Meta) |
| GET | /api/marketing/posts | Calendário editorial |
| POST | /api/marketing/posts | Criar post |
| GET | /api/marketing/ideas | Banco de ideias |
| POST | /api/proxy/claude | Proxy Claude API |
| POST | /api/proxy/gemini/image | Proxy Nano Banana 2 |
| POST | /api/proxy/elevenlabs/tts | Proxy ElevenLabs |
| POST | /api/proxy/tiny | Proxy Tiny ERP |
| GET | /api/proxy/status | Status das integrações |
| WS | /api/ws/live | WebSocket tempo real |

Documentação interativa (dev): https://localhost:8000/api/docs

---

## Uso estimado de recursos (KVM 1)

| Serviço | RAM estimada |
|---------|-------------|
| FastAPI (uvicorn) | ~150MB |
| PostgreSQL | ~200MB |
| Redis | ~50MB |
| Nginx | ~30MB |
| **Total** | **~430MB** |

Sobram ~3.5GB livres — confortável para crescer.

---

## Próximos passos

- [ ] Migrar dados hardcoded do HTML → banco (rodar seed script)
- [ ] Conectar frontend ao backend (trocar fetch local por /api/*)
- [ ] Configurar GitHub Actions para CI/CD automático
- [ ] Adicionar app React Native (Fase 7)
